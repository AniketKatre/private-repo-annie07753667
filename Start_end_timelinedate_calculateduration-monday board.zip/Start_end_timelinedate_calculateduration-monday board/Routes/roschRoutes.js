const express = require("express");
const { GenerateDynamicBoard } = require("../Controllers/generateDynamicBoard");
const {
  calculateCrossRowDateDifference,
} = require("../Controllers/calculateCrossRowDateDifference");
const roschRouter = express.Router();

roschRouter.post("/GenerateDynamicBoard", GenerateDynamicBoard);
roschRouter.post("/calculateDates", calculateCrossRowDateDifference);
// commented for demo purpose need to uncommented once demo is done for BP Roll up since it is not exposed from aks 1/2/2024

module.exports = roschRouter;
