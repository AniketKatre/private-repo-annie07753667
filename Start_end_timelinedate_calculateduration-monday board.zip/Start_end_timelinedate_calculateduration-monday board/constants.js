// constants = {
//   TemplateMap: {
//     "Rivers Temp": { FolderId: 17067241, templateId: 11598956 },
//     "Sea Temp": { FolderId: 17067249, templateId: 11598963 },
//   },
//   endDateColumnId: "date_mksrwka8",
//   startDateColumnId: "date_mksrv5cg",
//   resultColumnId: "numeric_mksrkrq0",
//   workspaceId: 9808183,
//   TOKEN:
//     "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ5ODI4MDQ1MCwiYWFpIjoxMSwidWlkIjoyMjMwMjEzMSwiaWFkIjoiMjAyNS0wNC0xMFQxMzowOTowNy4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6ODQ3MzgwMiwicmduIjoidXNlMSJ9.4ybL3j9iB1eImm0hGZna7JKUU4f-NuYJ1-uXUA3kkNw",
// };
// module.exports = { constants };
