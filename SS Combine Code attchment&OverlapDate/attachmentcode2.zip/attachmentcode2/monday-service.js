const initMondayClient = require("monday-sdk-js");

const getBoardsAllData = async (token, boardId) => {
  return new Promise(async (resolve, reject) => {
    try {
      const mondayClient = initMondayClient();
      mondayClient.setToken(token);
      mondayClient.setApiVersion("2023-10");
      const query = `query {
        boards (ids: [${boardId}]) {
          items_page(limit: 500) {
            items {
              id
              name
              column_values {
                id
                value
                text
              }
            }
          }
        }
      }`;
      const response = await mondayClient.api(query);
      resolve(response);
    } catch (err) {
      reject(err);
    }
  });
};

const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
  const mondayClient = initMondayClient({ token });
  const query = `mutation {
    change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value: """${value.replace(/"/g, '\"')}""") {
      id
    }
  }`;
  const response = await mondayClient.api(query);
  return response;
};

module.exports = {
  getBoardsAllData,
  changeColumnValue
};