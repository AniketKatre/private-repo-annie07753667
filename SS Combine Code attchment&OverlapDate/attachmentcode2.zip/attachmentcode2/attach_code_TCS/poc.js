var fs = require("fs");
const path = require("path");

// var upfile = 'sample.png';
// set auth token and query
const some = (upfile, itemId, columnId) => {
  // const upfile=path.resolve(__dirname, "random.png")

  var API_KEY =
    "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk";
  var query = `mutation ($file: File!) { add_file_to_column (file: $file, item_id: ${itemId}, column_id: "file_mkr4fpp") { id } }`;
  var url = "https://api.monday.com/v2/file";
  var boundary = "xxxxxxxxxx";
  var data = "";
  fs.readFile(upfile, function (err, content) {
    // simple catch error
    if (err) {
      console.error(err);
    }
    data += "--" + boundary + "\r\n";
    data += 'Content-Disposition: form-data; name="query"; \r\n';
    data += "Content-Type:application/json\r\n\r\n";
    data += "\r\n" + query + "\r\n";
    data += "--" + boundary + "\r\n";
    data +=
      'Content-Disposition: form-data; name="variables[file]"; filename="' +
      upfile +
      '"\r\n';
    data += "Content-Type:application/octet-stream\r\n\r\n";
    var payload = Buffer.concat([
      Buffer.from(data, "utf8"),
      new Buffer.from(content, "binary"),
      Buffer.from("\r\n--" + boundary + "--\r\n", "utf8"),
    ]);
    // construct request options
    var options = {
      method: "post",
      headers: {
        "Content-Type": "multipart/form-data; boundary=" + boundary,
        Authorization: API_KEY,
      },
      body: payload,
    };
    // make request
    fetch(url, options)
      .then((res) => res.json())
      .then((json) => console.log(json));
  });
};
module.exports = some;
