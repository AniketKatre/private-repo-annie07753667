require("dotenv").config();
const path = require("path");
const express = require("express");
const axios = require("axios");
const app = express();
const fs = require("fs");
const some = require("./poc");
// const {downloadFile} = require('./downloadfile')
app.use(express.json());
const mondayservice = require("./monday-service");
app.get("/", async (req, res) => {
  console.log("working!!!!!");

  const Parentdata = await axios.get(
    "https://api.smartsheet.com/2.0/sheets/1181787112820612",
    {
      headers: {
        Authorization: `Bearer rGxvagnQNlLCpV6T8y9pZJ8aCYM8WSIX4gSnZ`, //the token is a variable which holds the token
      },
    }
  );

  console.log(Parentdata.data.rows[1].cells[0].value, "Parentdata");
  parentIds = [];
  Parentdata.data.rows.map((item) => {
    parentIds.push({ name: item.cells[0].value, parentId: item.id });
  });

  const data = await axios.get(
    "https://api.smartsheet.com/2.0/sheets/1181787112820612/attachments",
    {
      headers: {
        Authorization: `Bearer rGxvagnQNlLCpV6T8y9pZJ8aCYM8WSIX4gSnZ`, //the token is a variable which holds the token
      },
    }
  ); //console.log(data1.data,"data")

  attachmentIds = [];
  data.data.data.map((item) => {
    attachmentIds.push({ id: item.parentId, aid: item.id });
  });
  const mergedArray = attachmentIds.map((urlObj) => {
    const parentObj = parentIds.find((parent) => parent.parentId === urlObj.id);
    return { ...urlObj, parentName: parentObj ? parentObj.name : "Unknown" };
  });
  console.log(mergedArray, "mergedArray");
  try {
    for (var i = 0; i < mergedArray.length; i++) {
      let item = mergedArray[i];
      console.log(item, "item");
      const getAttahcment = await axios.get(
        `https://api.smartsheet.com/2.0/sheets/1181787112820612/attachments/${item.aid}`,
        {
          headers: {
            Authorization: `Bearer rGxvagnQNlLCpV6T8y9pZJ8aCYM8WSIX4gSnZ`, //the token is a variable which holds the token
          },
        }
      );

      console.log(getAttahcment.data.name, "asdasd");
      const outputFilePath = path.resolve(__dirname, getAttahcment.data.name);
      await downloadFile(getAttahcment.data.url, outputFilePath);
      console.log(item.parentName, item.id, "asdsad", item);
      const d = await mondayservice.MatchItem(
        "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk",
        1974357689, //boardId ->change only this
        item.parentName,
        "name"
      ); //first
      console.log(d, "matched item id"); //  const item2=await mondayservice.createItem2(constants.TOKsEN,7532681441,getAttahcment.data.name) //  console.log(item2)
      some(outputFilePath, d); // -------------------------

      // const d2=await mondayservice.fileupload(constants.TOKEN,item2,"files_mkm7jx8",outputFilePath)

      // ------------------------- // const fileDataStream=await axios.get(getAttahcment.data.url,{responseType:'stream'}) // const fileType=getAttahcment.data.mimeType
      // console.log(fileDataStream.data,"fielnamdad")

      // fs.writeFile("./soemting",fileDataStream,(data)=>{
      //   console.log(data)
      // }) // FormData.append('file',fileDataStream.data,FileName) // console.log(FormData,"FM")
    }
  } catch (err) {
    console.log(err);
  }

  res.status(200).send("all working fine  !!!!!");
});
async function downloadFile(fileUrl, outputFilePath) {
  const writer = fs.createWriteStream(outputFilePath);

  const response = await axios({
    url: fileUrl,
    method: "GET",
    responseType: "stream",
  });

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}
app.listen(8080, () => {
  console.log("server running ");
});

//---------------------------------------------------------------------------------------------------------------------

//Commments Code

// require('dotenv').config()
// const path = require('path')
// const express = require('express')
// const axios = require('axios')
// const app = express()
// const fs = require('fs')
// //const some = require("./poc")
// // const {downloadFile} = require('./downloadfile')
// app.use(express.json())
// const mondayservice = require("./monday-service")

// app.get("/comments", async (req, res) => {
//   console.log('working!!!!!');

//   try {
//     // Step 1: Get all rows to map parentId to name
//     const parentRes = await axios.get('https://api.smartsheet.com/2.0/sheets/7465637094838148', {
//       headers: {
//         Authorization: `Bearer xGx3jOPqoU624PvqnEjMEe4UEAxDvC1tYFnxT`
//       }
//     });

//    // console.log(parentRes, "rvnfnbuinrjnfvuj")

//     const parentIds = parentRes.data.rows.map(row => ({
//       parentId: row.id,
//       name: row.cells[0]?.value || "Unnamed"
//     }));

//     // Step 2: Get discussions (comments)
//     const discussionRes = await axios.get('https://api.smartsheet.com/2.0/sheets/7465637094838148/discussions', {
//       headers: {
//         Authorization: `Bearer xGx3jOPqoU624PvqnEjMEe4UEAxDvC1tYFnxT`
//       }
//     });

//     const discussions = discussionRes.data.data;

//     //console.log(discussions, "cdldkdmjmnj")

//     // Step 3: Merge each discussion with the corresponding parent name
//     const merged = discussions.map(item => {
//       const parent = parentIds.find(p => p.parentId === item.parentId);
//       return {
//         parentName: parent ? parent.name : "Unknown",
//         parentId: item.parentId,
//         comment: item?.commentAttachments?.[0]?.comment || "No comment",
//         title: item.title
//       };
//     });

//     //console.log(merged, "mvrmbkm")

//     // Step 4: Push comments to Monday.com
//     for (const item of merged) {
//       const matchedItemId = await mondayservice.MatchItem(
//         "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk",
//         1924191001, // board ID
//         item.parentName,
//         "name"
//       );
//       console.log(matchedItemId, "mjnjnkb")

//       console.log(`Matched item: ${matchedItemId} for ${item.parentName}`);

//       if (matchedItemId) {
//         // const updateRes =  `mutation {
//         //       change_simple_column_value(item_id: ${matchedItemId}, board_id: 1924191001, column_id: "long_text_mkqfgdhm", value: "${item.title}")
//         //     }`
//         const updateRes =  await mondayservice.changeColumnValue(
//           "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk",
//           1924191001,
//           matchedItemId,
//           "long_text_mkqfgdhm",
//           item.title

//         )
//         console.log(updateRes.data, "Updated comment column");
//       }
//     }

//     res.status(200).send("Comments mapped and updated in Monday.com successfully!");
//   } catch (err) {
//     console.error(err);
//     res.status(500).send("Error occurred while processing comments.");
//   }
// });

// app.listen(8080, () => {
//   console.log('server running ')
// })
