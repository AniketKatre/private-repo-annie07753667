const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");
const monday = require("./monday-service");

const PROGRESS_FILE = path.join(__dirname, "migration-progress.json");

const loadProgress = () => {
  if (!fs.existsSync(PROGRESS_FILE)) return {};
  return JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
};

const saveProgress = (progress) => {
  fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress, null, 2));
};

const downloadFile = async (fileUrl, outputFilePath) => {
  const writer = fs.createWriteStream(outputFilePath);
  const response = await axios({ url: fileUrl, method: "GET", responseType: "stream" });
  response.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
};

const uploadFileToMonday = async (token, itemId, columnId, filePath) => {
  const query = `mutation ($file: File!) {
    add_file_to_column (file: $file, item_id: ${itemId}, column_id: "${columnId}") { id }
  }`;

  const form = new FormData();
  form.append("query", query);
  form.append("variables[file]", fs.createReadStream(filePath));

  const headers = {
    ...form.getHeaders(),
    Authorization: token,
  };

  const response = await axios.post("https://api.monday.com/v2/file", form, { headers });
  return response.data;
};

const migrateAttachments = async ({ smartsheetToken, smartsheetSheetId, mondayToken, mondayBoardId, matchColumnId, fileColumnId, matchColumnType, logColumnId }) => {
  const results = [];
  const progress = loadProgress();

  const sheetRes = await axios.get(`https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`, {
    headers: { Authorization: `Bearer ${smartsheetToken}` },
  });

  const rows = sheetRes.data.rows;
  console.log(`📄 Fetched ${rows.length} rows from Smartsheet.`);

  const mondayItems = await monday.getBoardsAllData(mondayToken, mondayBoardId);
  const items = mondayItems.data.boards[0].items_page.items;

  for (const item of items) {
    const itemId = item.id;
    const itemName = item.name;
    const itemLogs = [];

    if (progress[itemId] && progress[itemId].completed) {
      const msg = `⏭️ Skipping already completed item '${itemName}'`;
      console.log(msg);
      itemLogs.push(msg);
      await monday.changeColumnValue(mondayToken, mondayBoardId, itemId, logColumnId, itemLogs.join("\n"));
      continue;
    }

    const matchedRow = rows.find((row) =>
      row.cells.find((cell) => cell.columnId == matchColumnId && (cell.displayValue || cell.value) === itemName)
    );

    if (!matchedRow) {
      results.push({ item: itemName, status: "⚠️ No matching Smartsheet row" });
      continue;
    }

    const parentId = matchedRow.id;

    const attchRes = await axios.get(
      `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/rows/${parentId}/attachments`,
      { headers: { Authorization: `Bearer ${smartsheetToken}` } }
    );

    const fileCol = item.column_values.find((col) => col.id === fileColumnId);
    const existingFileNames = fileCol && fileCol.value ? fileCol.value.split("\n").map(x => x.trim()) : [];

    const attachments = attchRes.data.data.filter((att) => att.name);
    const alreadyUploaded = progress[itemId]?.uploadedFiles || [];
    let successCount = 0;
    let failedFiles = [];

    for (const attachment of attachments) {
      const filename = attachment.name;

      if (existingFileNames.includes(filename) || alreadyUploaded.includes(filename)) {
        const msg = `🟡 Skipping duplicate '${filename}' for '${itemName}'`;
        console.log(msg);
        itemLogs.push(msg);
        continue;
      }

      try {
        const fileDetail = await axios.get(
          `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments/${attachment.id}`,
          { headers: { Authorization: `Bearer ${smartsheetToken}` } }
        );

        const localPath = path.join(__dirname, "downloads", filename);
        await downloadFile(fileDetail.data.url, localPath);
        await uploadFileToMonday(mondayToken, itemId, fileColumnId, localPath);

        successCount++;
        progress[itemId] = progress[itemId] || { uploadedFiles: [] };
        progress[itemId].uploadedFiles.push(filename);
        saveProgress(progress);

        const msg = `✅ Uploaded '${filename}' to '${itemName}'`;
        console.log(msg);
        itemLogs.push(msg);
      } catch (e) {
        const msg = `❌ Error uploading '${filename}' for '${itemName}': ${e.message}`;
        console.error(msg);
        itemLogs.push(msg);
        failedFiles.push(filename);
      }
    }

    if (!progress[itemId]) progress[itemId] = {};
    progress[itemId].completed = true;
    saveProgress(progress);

    let logMessage = `📊 Uploaded ${successCount}/${attachments.length} attachments from Smartsheet.`;
    if (failedFiles.length > 0) {
      logMessage += ` Failed files: ${failedFiles.join(", ")}`;
    }
    itemLogs.push(logMessage);

    try {
      await monday.changeColumnValue(mondayToken, mondayBoardId, itemId, logColumnId, itemLogs.join("\n"));
    } catch (e) {
      console.error(`⚠️ Failed to write log column for '${itemName}':`, e.message);
    }

    results.push({
      item: itemName,
      status: logMessage
    });
  }

  return results;
};

module.exports = migrateAttachments;