require("dotenv").config();
const express = require("express");
const app = express();
const migrateAttachments = require("./migration-service");

app.use(express.json());

app.post("/migrate", async (req, res) => {
  try {
    const { smartsheetToken, smartsheetSheetId, mondayToken, mondayBoardId, matchColumnId, fileColumnId, matchColumnType, logColumnId } = req.body;

    if (!smartsheetToken || !smartsheetSheetId || !mondayToken || !mondayBoardId || !matchColumnId || !fileColumnId || !matchColumnType || !logColumnId) {
      return res.status(400).json({ error: "Missing required config fields" });
    }

    const results = await migrateAttachments({
      smartsheetToken,
      smartsheetSheetId,
      mondayToken,
      mondayBoardId,
      matchColumnId,
      fileColumnId,
      matchColumnType,
      logColumnId
    });

    res.status(200).json({ summary: results });
  } catch (err) {
    console.error("❌ Migration Failed:", err.message);
    res.status(500).json({ error: "Migration failed", details: err.message });
  }
});

app.listen(8080, () => {
  console.log("🚀 Server running on http://localhost:8080");
});