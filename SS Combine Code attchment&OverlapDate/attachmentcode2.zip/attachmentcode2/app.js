require("dotenv").config();
const express = require("express");
const app = express();
const migrateAttachments = require("./migration-service");
const { createTunnel } = require("./Helper/localtunnel");

app.use(express.json());

app.post("/migrateAttahmentfromSmartsheet", async (req, res) => {
  //   console.log("aa", req.body, (mondayToken = process.env.MONDAY_TOKEN));
  try {
    const {
      smartsheetToken,
      smartsheetSheetId,
      mondayToken = process.env.MONDAY_TOKEN,
      mondayBoardId,
      matchColumnId,
      fileColumnId,
      matchColumnType,
      logColumnId,
    } = req.body.payload.inboundFieldValues;

    // console.log(
    //   "pppppppaload",
    //   smartsheetToken,
    //   smartsheetSheetId,
    //   mondayToken,
    //   mondayBoardId,
    //   matchColumnId,
    //   fileColumnId,
    //   matchColumnType,
    //   logColumnId,
    //   req.body
    // );

    if (
      !smartsheetToken ||
      !smartsheetSheetId ||
      !mondayToken ||
      !mondayBoardId ||
      !matchColumnId ||
      !fileColumnId ||
      !matchColumnType ||
      !logColumnId
    ) {
      return res.status(400).json({ error: "Missing required config fields" });
    }

    const results = await migrateAttachments({
      smartsheetToken,
      smartsheetSheetId,
      mondayToken,
      mondayBoardId,
      matchColumnId,
      fileColumnId,
      matchColumnType,
      logColumnId,
    });

    res.status(200).json({ summary: results });
  } catch (err) {
    console.error("❌ Migration Failed:", err.message);
    res.status(500).json({ error: "Migration failed", details: err.message });
  }
});

app.listen(8080, () => {
  console.log("🚀 Server running on http://localhost:8080");
  createTunnel(8080);
});
