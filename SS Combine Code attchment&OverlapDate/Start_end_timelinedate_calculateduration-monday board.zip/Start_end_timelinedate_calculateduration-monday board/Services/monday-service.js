const initMondayClient = require("monday-sdk-js");

const getColumnValue = async (token, itemId, columnId) => {
  return new Promise(async (resolve, reject) => {
    // console.log(columnId,"column id");
    try {
      const mondayClient = initMondayClient();
      mondayClient.setToken(token);

      const query = `query {
    items (ids: ${itemId}) {
     
     column_values(ids:"${columnId}") {
      value
      text
     }
    }
   }`;

      const response = await mondayClient.api(query);

      resolve(response.data?.items[0]?.column_values[0]?.text);
    } catch (err) {
      // console.log('err',err,query);
      reject(err);
    }
  });
};

const getDateColumns = async (token, boardId) => {
  return new Promise(async (resolve, reject) => {
    // console.log(token, boardId, "column id");
    try {
      const mondayClient = initMondayClient();
      mondayClient.setToken(token);

      const query = `query{
          boards(ids:${boardId}){
          columns{
            title
            id
          }}
          }`;

      const response = await mondayClient.api(query);
      console.log("abcd****", response.data?.boards[0]);
      resolve(response?.data?.boards[0]?.columns);
    } catch (err) {
      console.log("err", err);
      reject(err);
    }
  });
};

const createBoardService = async (
  token,
  boardName,
  workspaceId,
  folderId,
  templateId
) => {
  return new Promise(async (resolve, reject) => {
    try {
      // console.log(teams,"tuu")
      const mondayClient = initMondayClient();
      mondayClient.setToken(token); // "query": "mutation {create_board (board_name: , board_kind: public) {id}}"
      let brd = '"' + boardName + '"';
      const query = `mutation{create_board(board_name:"${boardName}" board_kind:public template_id:${templateId} workspace_id:${workspaceId} folder_id:${folderId}){
     id
     groups{
      id
      title
     }
    }}`; // const variables = { columnId, itemId }; // console.log(columnId,itemId)
      console.log(query);
      const response = await mondayClient.api(query);
      console.log(response, "response");

      resolve(response?.data?.create_board);
    } catch (err) {
      console.log("error", err);

      reject(err);
    }
  });
};

const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
  return new Promise(async (resolve, reject) => {
    try {
      const mondayClient = initMondayClient({ token });
      const query = `mutation {
   change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value:"${value}") {
    id
   }
  }
   `;
      const response = await mondayClient.api(query);
      console.log(response, "reeeeeeeea");
      resolve(response);
    } catch (err) {
      console.log("err", err);

      reject(err);
    }
  });
};
var GetDatesfromitems = async (
  token,
  boardId,
  itemId,
  startDateColumnId,
  endDateColumnId
) => {
  return new Promise(async (resolve, reject) => {
    try {
      const mondayClient = initMondayClient();
      mondayClient.setToken(token);
      const query = ` query{
 
    boards(ids:${boardId}) {
     items_page(limit:500){
      items {
      id
      column_values(ids: [${(startDateColumnId, endDateColumnId)}]) {
       id
       text
      }
     
     }
    }
   }
 }`;
      const response = await mondayClient.api(query);
      console.log(response);
      resolve(response?.data.boards[0].items_page.items);
    } catch (err) {
      console.log(err, "err");
      reject(err);
    }
  });
};

module.exports = {
  getColumnValue,
  changeColumnValue,
  createBoardService,
  GetDatesfromitems,
  getDateColumns,
};
