const express = require("express");
require("dotenv").config();
const app = express();
app.use(express.json());
const { createTunnel } = require("./Helper/localtunnel");

const port = 8080 || process.env.PORT;

// const roschRouter = require("./Routes/roschRoutes");
const dateChanges = require("./Controllers/calculateDurationDays");

// routes endpointN
app.post("/duration", dateChanges.calculateCrossRowDateDifference2);

app.listen(port, () => {
  console.log("started listening on port 8080");
  createTunnel(port);
});
