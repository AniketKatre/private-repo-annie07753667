require("dotenv").config();
const path = require("path");
const express = require("express");
const axios = require("axios");
const fs = require("fs");
const app = express();
const some = require("./poc");
const mondayservice = require("./monday-service");
const { createTunnel } = require("./Helper/localtunnel");

app.use(express.json());

let cache = {};
const cacheFile = path.resolve(__dirname, "cache.json");
if (fs.existsSync(cacheFile)) {
  cache = JSON.parse(fs.readFileSync(cacheFile));
}

app.post("/migrateAttahmentfromSmartsheet", async (req, res) => {
  const {
    mondayBoardId,
    itemId,
    mondayFileColumnId,
    matchingColumnId,
    smartsheetMatchingColumnId,
    smartsheetSheetId,
    smartsheetToken = process.env.SMARTSHEET_TOKEN,
    mondayToken = process.env.MONDAY_TOKEN,
  } = req.body.payload.inboundFieldValues;

  console.log("\n****************** Incoming Recipe Payload *********");
  console.log({
    mondayBoardId,
    itemId,
    mondayFileColumnId,
    matchingColumnId,
    smartsheetMatchingColumnId,
    smartsheetSheetId,
  });

  const log = [];

  try {
    const sheetData = await axios.get(
      `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`,
      { headers: { Authorization: `Bearer ${smartsheetToken}` } }
    );

    const columns = sheetData.data.columns;
    const rows = sheetData.data.rows;

    let smartsheetColumnIdToUse = smartsheetMatchingColumnId;
    if (isNaN(smartsheetMatchingColumnId)) {
      const matchedColumn = columns.find(
        (col) => col.title === smartsheetMatchingColumnId
      );
      if (!matchedColumn) {
        return res.status(400).json({
          error: `Smartsheet column '${smartsheetMatchingColumnId}' not found`,
        });
      }
      smartsheetColumnIdToUse = matchedColumn.id;
    }

    const parentIds = rows.map((item) => {
      const matchCell = item.cells.find(
        (cell) => cell.columnId == smartsheetColumnIdToUse
      );
      return {
        name: matchCell?.value?.toString() || "Unnamed",
        parentId: item.id,
      };
    });

    const mergedArray = [];

    for (const row of parentIds) {
      console.log(
        `📦 Fetching attachments for row: ${row.name} (${row.parentId})`
      );

      const response = await axios.get(
        `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/rows/${row.parentId}/attachments`,
        {
          headers: { Authorization: `Bearer ${smartsheetToken}` },
        }
      );

      const attachments = response.data.data || [];
      if (!attachments.length) continue;

      for (const att of attachments) {
        // 🔍 NEW: Fetch full attachment details to get download URL
        const attDetails = await axios.get(
          `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments/${att.id}`,
          {
            headers: { Authorization: `Bearer ${smartsheetToken}` },
          }
        );

        // console.log("📥 Attachment Details Response:", attDetails.data);

        const fileUrl = attDetails.data?.url;
        if (!fileUrl) {
          console.log(`❌ Could not get file URL for attachment: ${att.name}`);
          continue;
        }

        mergedArray.push({
          parentId: row.parentId,
          parentName: row.name,
          aid: att.id,
          filename: att.name,
          url: fileUrl,
        });
      }
    }

    for (const item of mergedArray) {
      try {
        const { parentName, filename, url } = item;
        const filepath = path.resolve(__dirname, filename);

        const mondayItemId = await mondayservice.MatchItem(
          mondayToken,
          mondayBoardId,
          parentName,
          matchingColumnId || "name"
        );

        if (!mondayItemId) {
          console.log(`❌ Row ${parentName}: Item not found in monday.com.`);
          continue;
        }

        if (cache[parentName] && cache[parentName].includes(filename)) {
          console.log(
            `⚠️ Row ${parentName}: '${filename}' already uploaded, skipped.`
          );
          continue;
        }

        console.log(`📥 Downloading '${filename}' from ${url}`);
        await downloadFile(url, filepath);

        await some(filepath, mondayItemId, mondayFileColumnId);

        if (!cache[parentName]) cache[parentName] = [];
        cache[parentName].push(filename);

        console.log(
          `✅ Uploaded '${filename}' to monday.com item '${parentName}'`
        );
      } catch (err) {
        console.log(`❌ Error processing ${item.filename}: ${err.message}`);
      }
    }

    fs.writeFileSync(cacheFile, JSON.stringify(cache, null, 2));
    res.status(200).json({ message: "Migration completed", log });
  } catch (err) {
    console.error("❌ Critical error:", err);
    res.status(500).json({ error: err.message });
  }
});

async function downloadFile(fileUrl, outputFilePath) {
  const writer = fs.createWriteStream(outputFilePath);
  const response = await axios({
    url: fileUrl,
    method: "GET",
    responseType: "stream",
  });

  response.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}

app.listen(8080, () => {
  console.log("🚀 Server running on port 8080");
  createTunnel(8080);
});
