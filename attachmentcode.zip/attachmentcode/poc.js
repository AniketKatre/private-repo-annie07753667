// poc.js
const fs = require("fs");
const axios = require("axios");
const FormData = require("form-data");

async function uploadToMonday(filePath, itemId, columnId) {
  try {
    const file = fs.createReadStream(filePath);
    const form = new FormData();
    form.append("variables[file]", file);

    const mutation = `
      mutation ($file: File!) {
        add_file_to_column (file: $file, item_id: ${itemId}, column_id: "${columnId}") {
          id
        }
      }
    `;

    form.append("query", mutation);

    const response = await axios.post("https://api.monday.com/v2/file", form, {
      headers: {
        Authorization: process.env.MONDAY_TOKEN,
        ...form.getHeaders(),
      },
    });

    if (response.data.errors) {
      console.error("❌ Upload error:", response.data.errors);
    } else {
      console.log(`✅ Upload successful for ${filePath}`);
    }
  } catch (err) {
    console.error("❌ Error in uploadToMonday:", err.message);
  }
}

module.exports = uploadToMonday;

// const fs = require("fs");
// const path = require("path");

// const uploadFileToMonday = (upfile, itemId, columnId, apiKey) => {
//   var query = `mutation ($file: File!) { add_file_to_column (file: $file, item_id: ${itemId}, column_id: "${columnId}") { id } }`;
//   var url = "https://api.monday.com/v2/file";
//   var boundary = "xxxxxxxxxx";
//   var data = "";

//   fs.readFile(upfile, function (err, content) {
//     if (err) return console.error(err);

//     data += "--" + boundary + "\r\n";
//     data += 'Content-Disposition: form-data; name="query"; \r\n';
//     data += "Content-Type:application/json\r\n\r\n";
//     data += "\r\n" + query + "\r\n";
//     data += "--" + boundary + "\r\n";
//     data += `Content-Disposition: form-data; name="variables[file]"; filename="${upfile}"\r\n`;
//     data += "Content-Type:application/octet-stream\r\n\r\n";

//     const payload = Buffer.concat([
//       Buffer.from(data, "utf8"),
//       new Buffer.from(content, "binary"),
//       Buffer.from("\r\n--" + boundary + "--\r\n", "utf8"),
//     ]);

//     const options = {
//       method: "post",
//       headers: {
//         "Content-Type": "multipart/form-data; boundary=" + boundary,
//         Authorization: apiKey,
//       },
//       body: payload,
//     };

//     fetch(url, options)
//       .then((res) => res.json())
//       .then((json) => console.log(json));
//   });
// };

// module.exports = uploadFileToMonday;
