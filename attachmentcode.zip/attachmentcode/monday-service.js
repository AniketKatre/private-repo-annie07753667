const axios = require("axios");

async function MatchItem(
  token,
  boardId,
  valueToMatch,
  columnIdOrName = "name"
) {
  try {
    const query = `
      query {
        boards(ids: ${boardId}) {
          items {
            id
            name
            column_values {
              id
              text
              title
            }
          }
        }
      }
    `;

    const response = await axios.post(
      "https://api.monday.com/v2",
      { query },
      {
        headers: {
          Authorization: token,
          "Content-Type": "application/json",
        },
      }
    );

    const items = response.data.data.boards[0].items;

    for (const item of items) {
      // Match by item name
      if (
        columnIdOrName === "name" &&
        item.name.trim() === valueToMatch.trim()
      ) {
        console.log(`🎉🎉🎉 MATCHED by name: '${item.name}'`);
        return item.id;
      }

      // Match by column value
      for (const col of item.column_values) {
        if (col.id === columnIdOrName || col.title === columnIdOrName) {
          const cellValue = col.text?.trim();
          if (cellValue === valueToMatch.trim()) {
            console.log(
              `🎉🎉🎉 MATCHED '${valueToMatch}' in column '${col.title}' (ID: ${col.id})`
            );
            return item.id;
          }
        }
      }
    }

    console.log(`⚠️ No match found for '${valueToMatch}' on board ${boardId}`);
    return null;
  } catch (err) {
    console.error("❌ Error in MatchItem:", err.message);
    return null;
  }
}

module.exports = {
  MatchItem,
};

// const initMondayClient = require("monday-sdk-js");
// var request = require("request");

// var getBoardsAllData = async (token, boardId) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       console.log(boardId, "bd");
//       const mondayClient = initMondayClient();
//       mondayClient.setToken(token);
//       mondayClient.setApiVersion("2023-10");
//       const query = `query { boards(limit:10 ids:${boardId}) {
//     items_page(limit:500){
//      items {
//       id
//       name
//       column_values{
//        id
//        value
//       }
//      }
//     }
//    } }`; // const variables = { boardId };
//       setTimeout(async () => {
//         const response = await mondayClient.api(query); // console.log(response,query,"ppppppppppppppp")
//         resolve(response);
//       }, 5000);
//     } catch (err) {
//       reject(err);
//     }
//   });
// };

// const createColumn = async (token, i) => {
//   return new Promise(async (resolve, reject) => {
//     // console.log(columnId,"column id");
//     try {
//       const mondayClient = initMondayClient();
//       mondayClient.setToken(token);

//       const query = `mutation{
//  create_column(board_id: 7493933370, title:"Work Status${i}", description: "This is my work status column", column_type:status) {
//   id
//   title
//   description
//  }
// }`;
//       const response = await mondayClient.api(query);
//       resolve(response);
//     } catch (err) {
//       // console.log('err',err,query);
//       reject(err);
//     }
//   });
// };

// const createItem2 = async (token, boardId, itemName) => {
//   return new Promise(async (resolve, reject) => {
//     let query = "";
//     try {
//       const mondayClient = initMondayClient({ token });

//       query = `mutation {create_item(board_id: ${boardId} item_name: "${itemName}" ) {id}}`;
//       const variables = { boardId, itemName };
//       console.log(query);
//       const response = await mondayClient.api(query);
//       resolve(response.data.create_item.id);
//     } catch (err) {
//       console.log("err", err, query);
//       reject(err);
//     }
//   });
// };

// const MatchItem = async (token, boardId, name, clmid) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       // console.log(ids,"idsoo")
//       const ids2 = []; // ids.map((a)=>{ //  ids2.push(`"${a}"`) // })
//       const mondayClient = initMondayClient({ token });
//       mondayClient.setApiVersion("2023-10");
//       console.log(name, "smasrtheet name for match");
//       const query = `query {
//     items_page_by_column_values ( limit: 100, board_id: ${boardId}, columns: [{column_id: "${clmid}", column_values: ["${name}"]}]) {
//     items{
//      id
//      column_values{
//       value
//      }
//     }}}`;
//       const response = await mondayClient.api(query);
//       console.log(response?.data?.items_page_by_column_values, "jnbfhnbtkjgn"); // console.log(response, "res"); // console.log(response?.data?.items_page_by_column_values?.items[0]?.id, "nbjnjg")
//       resolve(response?.data?.items_page_by_column_values?.items[0]?.id);
//     } catch (err) {
//       console.log("err", err);
//       reject(err);
//     }
//   });
// };

// const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
//   return new Promise(async (resolve, reject) => {
//     try {
//       const mondayClient = initMondayClient({ token }); // const value2=JSON.parse(value)
//       const query = `mutation {
//    change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value:"${value}") {
//     id
//    }
//   }
//    `;
//       const response = await mondayClient.api(query); // console.log(response,"reeeeeeeea")
//       resolve(response);
//     } catch (err) {
//       console.log("err", err);
//       reject(err);
//     }
//   });
// };

// module.exports = {
//   getBoardsAllData,
//   createItem2,
//   createColumn,
//   MatchItem,
//   changeColumnValue,
// };
