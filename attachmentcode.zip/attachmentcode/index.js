require("dotenv").config();
const path = require("path");
const express = require("express");
const axios = require("axios");
const fs = require("fs");
const app = express();
const some = require("./poc"); // Upload file to Monday.com
const mondayservice = require("./monday-service");
const { createTunnel } = require("./Helper/localtunnel");

app.use(express.json());

let cache = {};
const cacheFile = path.resolve(__dirname, "cache.json");
if (fs.existsSync(cacheFile)) {
  cache = JSON.parse(fs.readFileSync(cacheFile));
}

app.post("/migrateAttahmentfromSmartsheet", async (req, res) => {
  const {
    mondayBoardId,
    itemId,
    mondayFileColumnId,
    matchingColumnId,
    smartsheetMatchingColumnId,
    smartsheetSheetId,
    smartsheetToken = process.env.SMARTSHEET_TOKEN,
    mondayToken = process.env.MONDAY_TOKEN,
  } = req.body.payload.inboundFieldValues;

  console.log("\n****************** Incoming Recipe Payload *********");
  console.log({
    mondayBoardId,
    itemId,
    mondayFileColumnId,
    matchingColumnId,
    smartsheetMatchingColumnId,
    smartsheetSheetId,
  });

  const log = [];

  try {
    console.log("📥 Fetching Smartsheet sheet data...");
    const sheetData = await axios.get(
      `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`,
      { headers: { Authorization: `Bearer ${smartsheetToken}` } }
    );

    console.log("✅ Sheet data fetched successfully.");
    const columns = sheetData.data.columns;
    const rows = sheetData.data.rows;
    console.log(`📊 Found ${columns.length} columns and ${rows.length} rows.`);

    let smartsheetColumnIdToUse = smartsheetMatchingColumnId;
    if (isNaN(smartsheetMatchingColumnId)) {
      console.log(
        `🔍 Resolving column title '${smartsheetMatchingColumnId}' to ID...`
      );
      const matchedColumn = columns.find(
        (col) => col.title === smartsheetMatchingColumnId
      );
      if (!matchedColumn) {
        return res.status(400).json({
          error: `Smartsheet column '${smartsheetMatchingColumnId}' not found`,
        });
      }
      smartsheetColumnIdToUse = matchedColumn.id;
      console.log(`✅ Resolved column title to ID: ${smartsheetColumnIdToUse}`);
    }

    const parentIds = rows.map((item) => {
      const matchCell = item.cells.find(
        (cell) => cell.columnId == smartsheetColumnIdToUse
      );
      return {
        name: matchCell?.value?.toString() || "Unnamed",
        parentId: item.id,
      };
    });

    console.log(`🔗 Mapped ${parentIds.length} parent rows.`);

    const mergedArray = [];

    for (const row of parentIds) {
      console.log(
        `📦 Fetching attachments for row: ${row.name} (${row.parentId})`
      );
      const response = await axios.get(
        `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/rows/${row.parentId}/attachments`,
        {
          headers: { Authorization: `Bearer ${smartsheetToken}` },
        }
      );

      const attachments = response.data.data || [];
      if (!attachments.length) {
        console.log(`ℹ️ Row ${row.name} has no attachments.`);
        continue;
      }

      console.log(
        `📎 Found ${attachments.length} attachments for row ${row.name}`
      );
      for (const att of attachments) {
        console.log(`🔗 Adding attachment '${att.name}' to processing queue.`);
        mergedArray.push({
          parentId: row.parentId,
          parentName: row.name,
          aid: att.id,
          filename: att.name,
          url: att.url,
        });
      }
    }

    for (const item of mergedArray) {
      try {
        const { parentName, filename, url } = item;
        const filepath = path.resolve(__dirname, filename);

        const mondayItemId = await mondayservice.MatchItem(
          mondayToken,
          mondayBoardId,
          parentName,
          matchingColumnId || "name"
        );

        if (!mondayItemId) {
          console.log(`❌ Row ${parentName}: Item not found in monday.com.`);
          log.push(`❌ Row ${parentName}: Item not found in monday.com.`);
          continue;
        }

        // ✅ Skip already uploaded files
        if (cache[parentName] && cache[parentName].includes(filename)) {
          console.log(
            `⚠️ Row ${parentName}: '${filename}' already uploaded, skipped.`
          );
          log.push(
            `⚠️ Row ${parentName}: '${filename}' already uploaded, skipped.`
          );
          continue;
        }

        // ✅ Download file if URL is valid
        console.log(
          `📥 Downloading file '${filename}' from Smartsheet: ${url}`
        );
        if (!url || typeof url !== "string" || !url.startsWith("http")) {
          console.log(`❌ Invalid URL for '${filename}', skipping.`);
          log.push(`❌ Invalid URL for '${filename}'`);
          continue;
        }

        await downloadFile(url, filepath);
        await some(filepath, mondayItemId, mondayFileColumnId);

        if (!cache[parentName]) cache[parentName] = [];
        cache[parentName].push(filename);

        console.log(`✅ Row ${parentName}: '${filename}' uploaded.`);
        log.push(`✅ Row ${parentName}: '${filename}' uploaded.`);
      } catch (err) {
        console.log(`❌ Row ${item.parentName}: Error - ${err.message}`);
        log.push(`❌ Row ${item.parentName}: Error - ${err.message}`);
      }
    }

    fs.writeFileSync(cacheFile, JSON.stringify(cache, null, 2));
    res.status(200).json({ message: "Migration completed", log });
  } catch (err) {
    console.error("❌ Critical error:", err);
    res.status(500).json({ error: err.message });
  }
});

async function downloadFile(fileUrl, outputFilePath) {
  const writer = fs.createWriteStream(outputFilePath);
  const response = await axios({
    url: fileUrl,
    method: "GET",
    responseType: "stream",
  });

  response.data.pipe(writer);

  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}

app.listen(8080, () => {
  console.log("🚀 Server running on port 8080");
  createTunnel(8080);
});

// // index.js
// require("dotenv").config();
// const path = require("path");
// const express = require("express");
// const axios = require("axios");
// const fs = require("fs");
// const app = express();
// const some = require("./poc");
// const mondayservice = require("./monday-service");
// const { createTunnel } = require("./Helper/localtunnel");

// app.use(express.json());

// let cache = {};
// const cacheFile = path.resolve(__dirname, "cache.json");
// if (fs.existsSync(cacheFile)) {
//   cache = JSON.parse(fs.readFileSync(cacheFile));
// }

// app.post("/migrateAttahmentfromSmartsheet", async (req, res) => {
//   //   console.log("***********", req.body);

//   const {
//     mondayBoardId,
//     itemId,
//     mondayFileColumnId,
//     matchingColumnId, // column_id in monday.com (optional)
//     smartsheetMatchingColumnId, // column_id or column name (label)
//     smartsheetSheetId,
//     smartsheetToken = process.env.SMARTSHEET_TOKEN,
//     mondayToken = process.env.MONDAY_TOKEN,
//   } = req.body.payload.inboundFieldValues;

//   console.log(
//     "*******************GGGG*********",
//     mondayBoardId,
//     itemId,
//     mondayFileColumnId,
//     matchingColumnId, // column_id in monday.com (optional)
//     smartsheetMatchingColumnId, // column_id or column name (label)
//     smartsheetSheetId
//   );

//   const log = [];

//   try {
//     const sheetData = await axios.get(
//       `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`,
//       {
//         headers: { Authorization: `Bearer ${smartsheetToken}` },
//       }
//     );

//     const columns = sheetData.data.columns;
//     const rows = sheetData.data.rows;

//     // console.log("COLUMN and ROW", columns);
//     // console.log("COLUMN and ROW", rows);

//     // Match smartsheet column label to ID if label was provided
//     let smartsheetColumnIdToUse = smartsheetMatchingColumnId;
//     if (isNaN(smartsheetMatchingColumnId)) {
//       const matchedColumn = columns.find(
//         (col) => col.title === smartsheetMatchingColumnId
//       );
//       if (!matchedColumn) {
//         return res.status(400).json({
//           error: `Smartsheet column '${smartsheetMatchingColumnId}' not found`,
//         });
//       }
//       smartsheetColumnIdToUse = matchedColumn.id;
//     }

//     // console.log("SS column ID : ***", smartsheetColumnIdToUse);

//     const parentIds = rows.map((item) => {
//       const matchCell = item.cells.find(
//         (cell) => cell.columnId == smartsheetColumnIdToUse
//       );
//       return {
//         name: matchCell?.value || "Unnamed",
//         parentId: item.id,
//       };
//     });

//     const allAttachments = await axios.get(
//       `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments`,
//       {
//         headers: { Authorization: `Bearer ${smartsheetToken}` },
//       }
//     );

//     const attachmentIds = allAttachments.data.data.map((item) => ({
//       id: item.parentId,
//       aid: item.id,
//     }));

//     // console.log("SS attachmentIds+++ ", attachmentIds);

//     const mergedArray = attachmentIds.map((urlObj) => {
//       const parentObj = parentIds.find((p) => p.parentId === urlObj.id);
//       return {
//         ...urlObj,
//         parentName: parentObj ? parentObj.name : "Unknown",
//       };
//     });

//     // console.log("SS mergedArray+++ ", mergedArray);

//     for (const item of mergedArray) {
//       try {
//         const attachmentMeta = await axios.get(
//           `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments/${item.aid}`,
//           {
//             headers: { Authorization: `Bearer ${smartsheetToken}` },
//           }
//         );

//         const filename = attachmentMeta.data.name;
//         const downloadUrl = attachmentMeta.data.url;
//         const filepath = path.resolve(__dirname, filename);

//         // console.log(
//         //   "ATTCAHMNET NAME , DL-URL, AND Filapath",
//         //   filename,
//         //   downloadUrl,
//         //   filepath
//         // );

//         const mondayItemId = await mondayservice.MatchItem(
//           mondayToken,
//           mondayBoardId,
//           item.parentName,
//           matchingColumnId || "name"
//         );

//         // console.log(
//         //   "############## mondayItemId",
//         //   mondayItemId,
//         //   item.parentName
//         // );

//         if (!mondayItemId) {
//           log.push(`❌ Row ${item.parentName}: Item not found in monday.com.`);
//           continue;
//         }

//         if (
//           cache[item.parentName] &&
//           cache[item.parentName].includes(filename)
//         ) {
//           console.log(
//             `⚠️ Row ${item.parentName}: '${filename}' already uploaded, skipped.`
//           );
//           log.push(
//             `⚠️ Row ${item.parentName}: '${filename}' already uploaded, skipped.`
//           );
//           continue;
//         }

//         await downloadFile(downloadUrl, filepath);
//         await some(filepath, mondayItemId, mondayFileColumnId);

//         if (!cache[item.parentName]) cache[item.parentName] = [];
//         cache[item.parentName].push(filename);
//         console.log(`✅ Row ${item.parentName}: '${filename}' uploaded.`);

//         log.push(`✅ Row ${item.parentName}: '${filename}' uploaded.`);
//       } catch (err) {
//         log.push(`❌ Row ${item.parentName}: Error - ${err.message}`);
//       }
//     }

//     fs.writeFileSync(cacheFile, JSON.stringify(cache, null, 2));
//     res.status(200).json({ message: "Migration completed", log });
//   } catch (err) {
//     console.error("❌ Critical error:", err);
//     res.status(500).json({ error: err.message });
//   }
// });

// async function downloadFile(fileUrl, outputFilePath) {
//   const writer = fs.createWriteStream(outputFilePath);
//   const response = await axios({
//     url: fileUrl,
//     method: "GET",
//     responseType: "stream",
//   });
//   response.data.pipe(writer);
//   return new Promise((resolve, reject) => {
//     writer.on("finish", resolve);
//     writer.on("error", reject);
//   });
// }

// app.listen(8080, () => {
//   console.log("🚀 Server running on port 8080");
//   createTunnel(8080);
// });
