const axios = require("axios");

// Fetch discussions (comments) for a specific row in a Smartsheet
const getDiscussions = async (sheetId, rowId, token) => {
  const url = `https://api.smartsheet.com/2.0/sheets/${sheetId}/rows/${rowId}/discussions`;

  try {
    console.log(`🔗 Fetching discussions from: ${url}`);
    const response = await axios.get(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const discussions = response.data?.data || [];
    console.log(
      `📦 Fetched ${discussions.length} discussions for row ${rowId}`
    );
    return discussions;
  } catch (error) {
    console.error(
      `❌ Failed to fetch discussions for row ${rowId}`,
      error.response?.data || error.message
    );
    return [];
  }
};

// Format discussion and replies into a markdown-styled update for monday.com
const formatCommentWithReplies = (discussion) => {
  console.log("Inside - formatCommentWithReplies:-", discussion);

  const title = discussion?.title?.trim();
  const createdAt = discussion?.lastCommentedAt;
  const name =
    discussion?.lastCommentedUser?.name ||
    discussion?.createdBy?.name ||
    "Unknown";
  const email =
    discussion?.lastCommentedUser?.email ||
    discussion?.createdBy?.email ||
    "N/A";

  if (!title) return "";

  const formatted = [];

  formatted.push(`${title}`);
  formatted.push(`\n\n🕒 ${new Date(createdAt).toLocaleString()}`);
  formatted.push(`👤 Commented by: ${name} (${email})`);

  // Join with double line break for markdown rendering
  return formatted.join("\n");
};

module.exports = {
  getDiscussions,
  formatCommentWithReplies,
};
