// const monday_service = require("../Services/monday-service");

const calculateCrossRowDateDiff_GroupBy = async (req, res) => {
  try {
    const wdSet = new Set();
    const groupedItems = {};

    // Extract fields from payload
    const {
      boardId,
      startDateColumnID,
      endDateColumnID,
      durationColumnId,
      timelineColumnId,
      statusColumnId,
    } = req.body.payload.inboundFieldValues;

    const apiKey =
      "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk";

    // Log the incoming payload info
    console.log("🚀 Incoming Payload Info:");
    console.log("Board ID:", boardId);
    console.log("Start Date Column ID:", startDateColumnID);
    console.log("End Date Column ID:", endDateColumnID);
    console.log("Duration Column ID:", durationColumnId);
    console.log("Timeline Column ID:", timelineColumnId);
    console.log("Status Column ID:", statusColumnId);

    if (!boardId || !durationColumnId || !statusColumnId) {
      return res.status(400).send({
        error:
          "❌ Missing required: boardId, durationColumnId, or statusColumnId in payload.",
      });
    }

    // Determine logic mode
    const usingTimeline = !!timelineColumnId;
    const usingDateColumns = startDateColumnID && endDateColumnID;

    if (!usingTimeline && !usingDateColumns) {
      return res.status(400).send({
        error:
          "❌ Provide either both Start/End Date columns or a Timeline column in the payload.",
      });
    }

    if (usingTimeline) {
      console.log("📦 Running in TIMELINE mode.");
    } else {
      console.log("📦 Running in DATE mode.");
    }

    const columnIdsToFetch = usingTimeline
      ? [timelineColumnId, statusColumnId]
      : [startDateColumnID, endDateColumnID, statusColumnId];

    const fetchItemsQuery = `
      query {
        boards(ids: ${boardId}) {
          items_page {
            items {
              id
              name
              column_values(ids: ${JSON.stringify(columnIdsToFetch)}) {
                id
                text
                value
              }
            }
          }
        }
      }
    `;

    async function mondayApiRequest(query) {
      const response = await fetch("https://api.monday.com/v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: apiKey,
        },
        body: JSON.stringify({ query }),
      });

      const jsonResponse = await response.json();
      return jsonResponse;
    }

    const data = await mondayApiRequest(fetchItemsQuery);

    if (!data || !data.data || !data.data.boards || !data.data.boards.length) {
      console.error("❌ API response missing boards data.");
      return res.status(500).send({
        error: "Failed to retrieve board items. Check column IDs or token.",
      });
    }

    const items = data.data.boards[0].items_page.items;

    if (!items || items.length === 0) {
      console.log("ℹ️ No items found on the board.");
      return res.status(200).send({ message: "No items to process." });
    }

    // Process each item and group by status label
    for (const item of items) {
      let startDate, endDate;

      const statusValue =
        item.column_values.find((cv) => cv.id === statusColumnId)?.text ||
        "Unknown";

      if (!groupedItems[statusValue]) {
        groupedItems[statusValue] = [];
      }

      if (usingTimeline) {
        const timelineValue = item.column_values.find(
          (cv) => cv.id === timelineColumnId
        );

        if (!timelineValue?.value) {
          console.warn(`⚠️ Timeline missing for item ${item.id}. Skipping.`);
          continue;
        }

        let timelineData;
        try {
          timelineData = JSON.parse(timelineValue.value);
        } catch (err) {
          console.warn(
            `⚠️ Failed to parse timeline for item ${item.id}. Skipping.`
          );
          continue;
        }

        startDate = new Date(timelineData.from);
        endDate = new Date(timelineData.to);

        console.log(
          `🕓 [Timeline Mode] Item ${
            item.id
          } - Start: ${startDate.toISOString()}, End: ${endDate.toISOString()}`
        );
      } else {
        const startText = item.column_values.find(
          (cv) => cv.id === startDateColumnID
        )?.text;
        const endText = item.column_values.find(
          (cv) => cv.id === endDateColumnID
        )?.text;

        if (!startText || !endText) {
          console.warn(
            `⚠️ Item ${item.id} skipped - missing Start or End date.`
          );
          continue;
        }

        startDate = new Date(startText);
        endDate = new Date(endText);

        console.log(
          `📅 [Date Mode] Item ${item.id} - Start: ${startText}, End: ${endText}`
        );
      }

      if (!startDate || !endDate || isNaN(startDate) || isNaN(endDate)) {
        console.warn(`⚠️ Invalid date values for item ${item.id}. Skipping.`);
        continue;
      }

      // Push item into group
      groupedItems[statusValue].push({ item, startDate, endDate });
    }

    // Calculate and update working days per group
    for (const label in groupedItems) {
      const itemsInGroup = groupedItems[label];
      const groupSet = new Set();

      console.log(`🧩 Group: ${label} - ${itemsInGroup.length} items`);

      for (const entry of itemsInGroup) {
        const { item, startDate, endDate } = entry;
        const workingDays = getWorkingDays(startDate, endDate, groupSet);

        console.log(
          `📊 [${label}] Item ${item.id} → Working Days: ${workingDays}`
        );

        const updateColumnValueQuery = `
          mutation {
            change_simple_column_value (
              board_id: ${boardId},
              item_id: ${item.id},
              column_id: "${durationColumnId}",
              value: "${workingDays}"
            ) {
              id
            }
          }
        `;

        await mondayApiRequest(updateColumnValueQuery);
      }
    }

    console.log("✅ All durations updated successfully per status label.");
    res
      .status(200)
      .send({ message: "Durations updated per group successfully." });
  } catch (err) {
    console.error("❌ Error calculating duration:", err);
    res.status(500).send({ error: err.message || "Internal Server Error" });
  }
};

// Function to calculate working days (excludes weekends)
function getWorkingDays(startDate, endDate, wdSet) {
  const countedWorkingDays = new Set();
  const start = new Date(startDate);
  const end = new Date(endDate);
  let workingDaysInRange = 0;

  const currentDate = new Date(start);
  while (currentDate <= end) {
    const dateString = currentDate.toISOString().split("T")[0];

    if (!wdSet.has(dateString)) {
      wdSet.add(dateString);
      const dayOfWeek = currentDate.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) {
        if (!countedWorkingDays.has(dateString)) {
          countedWorkingDays.add(dateString);
          workingDaysInRange++;
        }
      }
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return workingDaysInRange;
}

module.exports = { calculateCrossRowDateDiff_GroupBy };
