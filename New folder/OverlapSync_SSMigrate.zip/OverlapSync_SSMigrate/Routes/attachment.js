// routes/attachment.js
const express = require("express");
const router = express.Router();
const migrateAttachments = require("../SS_Attachment_MigrationControl/migration-service");

router.post("/AttahmentfromSmartsheet", async (req, res) => {
  try {
    console.log("aaaa");
    const {
      smartsheetToken,
      smartsheetSheetId,
      mondayToken = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjQ0MjY1NTgwNiwiYWFpIjoxMSwidWlkIjo2NTQwMDU3NCwiaWFkIjoiMjAyNC0xMS0yOVQxMToxODozNC4wMDBaIiwicGVyIjoibWU6d3JpdGUiLCJhY3RpZCI6OTc0MzQ5NiwicmduIjoiZXVjMSJ9.Rv0pghuy_F701lyBK_Sv0fut3bdMB7IsqCD5reBkbYk",
      mondayBoardId,
      matchColumnId,
      fileColumnId,
      matchColumnType,
      logColumnId,
    } = req.body.payload.inboundFieldValues;

    // console.log(
    //   "aaaa",
    //   smartsheetToken,
    //   smartsheetSheetId,
    //   mondayBoardId,
    //   matchColumnId,
    //   fileColumnId,
    //   matchColumnType,
    //   logColumnId
    // );

    if (
      !smartsheetToken ||
      !smartsheetSheetId ||
      !mondayToken ||
      !mondayBoardId ||
      !matchColumnId ||
      !fileColumnId ||
      !matchColumnType ||
      !logColumnId
    ) {
      return res.status(400).json({ error: "Missing required config fields" });
    }

    const results = await migrateAttachments({
      smartsheetToken,
      smartsheetSheetId,
      mondayToken,
      mondayBoardId,
      matchColumnId,
      fileColumnId,
      matchColumnType,
      logColumnId,
    });

    res.status(200).json({ summary: results });
  } catch (err) {
    console.error("❌ Migration Failed:", err.message);
    res.status(500).json({ error: "Migration failed", details: err.message });
  }
});

module.exports = router;
