const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");
const monday = require("./monday-service");

const downloadFile = async (fileUrl, outputFilePath) => {
  const writer = fs.createWriteStream(outputFilePath);
  const response = await axios({
    url: fileUrl,
    method: "GET",
    responseType: "stream",
  });
  response.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
};

const uploadFileToMonday = async (token, itemId, columnId, filePath) => {
  const query = `mutation ($file: File!) {
    add_file_to_column (file: $file, item_id: ${itemId}, column_id: "${columnId}") { id }
  }`;

  const form = new FormData();
  form.append("query", query);
  form.append("variables[file]", fs.createReadStream(filePath));

  const headers = {
    ...form.getHeaders(),
    Authorization: token,
  };

  const response = await axios.post("https://api.monday.com/v2/file", form, {
    headers,
  });

  return response.data;
};

// ✅ Retry wrapper for uploadFileToMonday
const retryUploadFileToMonday = async (
  token,
  itemId,
  columnId,
  filePath,
  retries = 3
) => {
  let lastError = null;
  for (let i = 0; i < retries; i++) {
    try {
      return await uploadFileToMonday(token, itemId, columnId, filePath);
    } catch (err) {
      lastError = err;
      console.error(
        `❌ Upload failed (attempt ${i + 1}) for ${filePath}:`,
        err.message
      );
      await new Promise((res) => setTimeout(res, 2000)); // Wait 2s before retry
    }
  }
  throw lastError;
};

const migrateAttachments = async ({
  smartsheetToken,
  smartsheetSheetId,
  mondayToken,
  mondayBoardId,
  matchColumnId,
  fileColumnId,
  matchColumnType,
  logColumnId,
}) => {
  const PROGRESS_DIR = path.join(__dirname, "SS-Attachment-Migration");
  if (!fs.existsSync(PROGRESS_DIR)) fs.mkdirSync(PROGRESS_DIR);

  const PROGRESS_FILE = path.join(
    PROGRESS_DIR,
    `migration-progress-${mondayBoardId}-${smartsheetSheetId}.json`
  );

  const loadProgress = () => {
    if (!fs.existsSync(PROGRESS_FILE)) return {};
    return JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
  };

  const saveProgress = (progress) => {
    fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress, null, 2));
  };

  const results = [];
  const progress = loadProgress();

  const sheetRes = await axios.get(
    `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`,
    {
      headers: { Authorization: `Bearer ${smartsheetToken}` },
    }
  );

  const rows = sheetRes.data.rows;
  const columns = sheetRes.data.columns;
  console.log(`📄 Fetched ${rows.length} rows from Smartsheet.`);

  if (isNaN(matchColumnId)) {
    const found = columns.find((c) => c.title.trim() === matchColumnId.trim());
    if (!found)
      throw new Error(`❌ Smartsheet column '${matchColumnId}' not found`);
    matchColumnId = found.id;
    console.log(
      `🔄 Resolved column name '${found.title}' to ID: ${matchColumnId}`
    );
  }

  const mondayItemsRes = await monday.getAllBoardItemsPaginated(
    mondayToken,
    mondayBoardId
  );
  const items = mondayItemsRes.data.items;

  for (const item of items) {
    const itemId = item.id;
    const itemName = item.name;
    const itemLogs = [];

    const logColumn = item.column_values.find((col) => col.id === logColumnId);
    const previousLog = logColumn?.text || "";

    let matchValue = item.name;
    if (matchColumnType !== "name") {
      const matchCol = item.column_values.find((c) => c.id === matchColumnType);
      matchValue = matchCol?.text || matchCol?.value || item.name;
    }

    if (progress[itemId] && progress[itemId].completed) {
      const msg = `⏭️ Skipping already completed item '${matchValue}'`;
      console.log(msg);
      itemLogs.push(msg);
      await monday.changeColumnValue(
        mondayToken,
        mondayBoardId,
        itemId,
        logColumnId,
        previousLog + "\n" + itemLogs.join("\n")
      );
      continue;
    }

    const matchedRow = rows.find((row) =>
      row.cells.find(
        (cell) =>
          cell.columnId == matchColumnId &&
          (cell.displayValue || cell.value) === matchValue
      )
    );

    if (!matchedRow) {
      results.push({
        item: matchValue,
        status: "⚠️ No matching Smartsheet row",
      });
      continue;
    }

    const parentId = matchedRow.id;

    const attchRes = await axios.get(
      `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/rows/${parentId}/attachments`,
      { headers: { Authorization: `Bearer ${smartsheetToken}` } }
    );

    const fileCol = item.column_values.find((col) => col.id === fileColumnId);
    const existingFileNames =
      fileCol && fileCol.value
        ? fileCol.value.split("\n").map((x) => x.trim())
        : [];

    const attachments = attchRes.data.data.filter((att) => att.name);
    const alreadyUploaded = progress[itemId]?.uploadedFiles || [];

    for (const attachment of attachments) {
      const filename = attachment.name;

      if (
        existingFileNames.includes(filename) ||
        alreadyUploaded.includes(filename)
      ) {
        const msg = `🟡 Skipping duplicate '${filename}' for '${matchValue}'`;
        console.log(msg);
        itemLogs.push(msg);
        continue;
      }

      try {
        const fileDetail = await axios.get(
          `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments/${attachment.id}`,
          { headers: { Authorization: `Bearer ${smartsheetToken}` } }
        );

        const localPath = path.join(__dirname, "downloads", filename);
        await downloadFile(fileDetail.data.url, localPath);

        // ✅ Retry + Upload
        await retryUploadFileToMonday(
          mondayToken,
          itemId,
          fileColumnId,
          localPath
        );

        // ✅ Delete if upload succeeded
        fs.unlink(localPath, (err) => {
          if (err) {
            console.error(`⚠️ Failed to delete ${localPath}:`, err);
          } else {
            console.log(`Deleted temp file:`);
          }
        });

        progress[itemId] = progress[itemId] || { uploadedFiles: [] };
        progress[itemId].uploadedFiles.push(filename);
        saveProgress(progress);

        const msg = `✅ Uploaded '${filename}' to '${matchValue}'`;
        console.log(msg);
        itemLogs.push(msg);
      } catch (e) {
        const msg = `❌ Error uploading '${filename}' for '${matchValue}': ${e.message}`;
        console.error(msg);
        itemLogs.push(msg);
      }
    }

    if (!progress[itemId]) progress[itemId] = {};
    progress[itemId].completed = true;
    saveProgress(progress);

    const totalUploaded = progress[itemId].uploadedFiles?.length || 0;
    const logMessage = `📦 Cumulative: ${totalUploaded}/${attachments.length} attachments uploaded from Smartsheet.`;
    itemLogs.push(logMessage);

    try {
      await monday.changeColumnValue(
        mondayToken,
        mondayBoardId,
        itemId,
        logColumnId,
        previousLog + "\n" + itemLogs.join("\n")
      );
    } catch (e) {
      console.error(
        `⚠️ Failed to write log column for '${matchValue}':`,
        e.message
      );
    }

    results.push({
      item: matchValue,
      status: logMessage,
    });
  }

  return results;
};

module.exports = migrateAttachments;

// const fs = require("fs");
// const path = require("path");
// const axios = require("axios");
// const FormData = require("form-data");
// const monday = require("./monday-service");

// const downloadFile = async (fileUrl, outputFilePath) => {
//   const writer = fs.createWriteStream(outputFilePath);
//   const response = await axios({
//     url: fileUrl,
//     method: "GET",
//     responseType: "stream",
//   });
//   response.data.pipe(writer);
//   return new Promise((resolve, reject) => {
//     writer.on("finish", resolve);
//     writer.on("error", reject);
//   });
// };

// const uploadFileToMonday = async (token, itemId, columnId, filePath) => {
//   const query = `mutation ($file: File!) {
//     add_file_to_column (file: $file, item_id: ${itemId}, column_id: "${columnId}") { id }
//   }`;

//   const form = new FormData();
//   form.append("query", query);
//   form.append("variables[file]", fs.createReadStream(filePath));

//   const headers = {
//     ...form.getHeaders(),
//     Authorization: token,
//   };

//   const response = await axios.post("https://api.monday.com/v2/file", form, {
//     headers,
//   });
//   return response.data;
// };

// const migrateAttachments = async ({
//   smartsheetToken,
//   smartsheetSheetId,
//   mondayToken,
//   mondayBoardId,
//   matchColumnId,
//   fileColumnId,
//   matchColumnType,
//   logColumnId,
// }) => {
//   // ✅ Use dynamic file name per board+sheet
//   // const PROGRESS_FILE = path.join(
//   //   __dirname,
//   //   `migration-progress-${mondayBoardId}-${smartsheetSheetId}.json`
//   // );

//   // console.log("ssssssssssss");

//   const PROGRESS_DIR = path.join(__dirname, "SS-Attachment-Migration");
//   if (!fs.existsSync(PROGRESS_DIR)) fs.mkdirSync(PROGRESS_DIR);

//   const PROGRESS_FILE = path.join(
//     PROGRESS_DIR,
//     `migration-progress-${mondayBoardId}-${smartsheetSheetId}.json`
//   );

//   const loadProgress = () => {
//     if (!fs.existsSync(PROGRESS_FILE)) return {};
//     return JSON.parse(fs.readFileSync(PROGRESS_FILE, "utf-8"));
//   };

//   const saveProgress = (progress) => {
//     fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress, null, 2));
//   };

//   const results = [];
//   const progress = loadProgress();

//   const sheetRes = await axios.get(
//     `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`,
//     {
//       headers: { Authorization: `Bearer ${smartsheetToken}` },
//     }
//   );

//   const rows = sheetRes.data.rows;
//   const columns = sheetRes.data.columns;
//   console.log(`📄 Fetched ${rows.length} rows from Smartsheet.`);

//   // Resolve matchColumnId if it's a column name
//   if (isNaN(matchColumnId)) {
//     const found = columns.find((c) => c.title.trim() === matchColumnId.trim());
//     if (!found)
//       throw new Error(`❌ Smartsheet column '${matchColumnId}' not found`);
//     matchColumnId = found.id;
//     console.log(
//       `🔄 Resolved column name '${found.title}' to ID: ${matchColumnId}`
//     );
//   }

//   const mondayItemsRes = await monday.getAllBoardItemsPaginated(
//     mondayToken,
//     mondayBoardId
//   );
//   const items = mondayItemsRes.data.items;

//   for (const item of items) {
//     const itemId = item.id;
//     const itemName = item.name;
//     const itemLogs = [];

//     const logColumn = item.column_values.find((col) => col.id === logColumnId);
//     const previousLog = logColumn?.text || "";

//     let matchValue = item.name;
//     if (matchColumnType !== "name") {
//       const matchCol = item.column_values.find((c) => c.id === matchColumnType);
//       matchValue = matchCol?.text || matchCol?.value || item.name;
//     }

//     if (progress[itemId] && progress[itemId].completed) {
//       const msg = `⏭️ Skipping already completed item '${matchValue}'`;
//       console.log(msg);
//       itemLogs.push(msg);
//       await monday.changeColumnValue(
//         mondayToken,
//         mondayBoardId,
//         itemId,
//         logColumnId,
//         previousLog + "\n" + itemLogs.join("\n")
//       );
//       continue;
//     }

//     const matchedRow = rows.find((row) =>
//       row.cells.find(
//         (cell) =>
//           cell.columnId == matchColumnId &&
//           (cell.displayValue || cell.value) === matchValue
//       )
//     );

//     if (!matchedRow) {
//       results.push({
//         item: matchValue,
//         status: "⚠️ No matching Smartsheet row",
//       });
//       continue;
//     }

//     const parentId = matchedRow.id;

//     const attchRes = await axios.get(
//       `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/rows/${parentId}/attachments`,
//       { headers: { Authorization: `Bearer ${smartsheetToken}` } }
//     );

//     const fileCol = item.column_values.find((col) => col.id === fileColumnId);
//     const existingFileNames =
//       fileCol && fileCol.value
//         ? fileCol.value.split("\n").map((x) => x.trim())
//         : [];

//     const attachments = attchRes.data.data.filter((att) => att.name);
//     const alreadyUploaded = progress[itemId]?.uploadedFiles || [];
//     let successCount = 0;
//     let failedFiles = [];

//     for (const attachment of attachments) {
//       const filename = attachment.name;

//       if (
//         existingFileNames.includes(filename) ||
//         alreadyUploaded.includes(filename)
//       ) {
//         const msg = `🟡 Skipping duplicate '${filename}' for '${matchValue}'`;
//         console.log(msg);
//         itemLogs.push(msg);
//         continue;
//       }

//       try {
//         const fileDetail = await axios.get(
//           `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}/attachments/${attachment.id}`,
//           { headers: { Authorization: `Bearer ${smartsheetToken}` } }
//         );

//         const localPath = path.join(__dirname, "downloads", filename);
//         await downloadFile(fileDetail.data.url, localPath);
//         // await uploadFileToMonday(mondayToken, itemId, fileColumnId, localPath);

//         try {
//           await uploadFileToMonday(
//             mondayToken,
//             itemId,
//             fileColumnId,
//             localPath
//           );

//           // 🔥 Delete file after successful upload
//           fs.unlink(localPath, (err) => {
//             if (err) {
//               console.error(`⚠️ Failed to delete ${localPath}:`, err);
//             } else {
//               console.log(`🧹 Deleted temp file: ${localPath}`);
//             }
//           });
//         } catch (err) {
//           console.error(`❌ Failed to upload ${localPath}:`, err.message);
//           // Optional: Keep file if upload fails for retry
//         }

//         successCount++;
//         progress[itemId] = progress[itemId] || { uploadedFiles: [] };
//         progress[itemId].uploadedFiles.push(filename);
//         saveProgress(progress);

//         const msg = `✅ Uploaded '${filename}' to '${matchValue}'`;
//         console.log(msg);
//         itemLogs.push(msg);
//       } catch (e) {
//         const msg = `❌ Error uploading '${filename}' for '${matchValue}': ${e.message}`;
//         console.error(msg);
//         itemLogs.push(msg);
//         failedFiles.push(filename);
//       }
//     }

//     if (!progress[itemId]) progress[itemId] = {};
//     progress[itemId].completed = true;
//     saveProgress(progress);

//     const totalUploaded = progress[itemId].uploadedFiles?.length || 0;
//     const logMessage = `📦 Cumulative: ${totalUploaded}/${attachments.length} attachments uploaded from Smartsheet.`;
//     itemLogs.push(logMessage);

//     try {
//       await monday.changeColumnValue(
//         mondayToken,
//         mondayBoardId,
//         itemId,
//         logColumnId,
//         previousLog + "\n" + itemLogs.join("\n")
//       );
//     } catch (e) {
//       console.error(
//         `⚠️ Failed to write log column for '${matchValue}':`,
//         e.message
//       );
//     }

//     results.push({
//       item: matchValue,
//       status: logMessage,
//     });
//   }

//   return results;
// };

// module.exports = migrateAttachments;
