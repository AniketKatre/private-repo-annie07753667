const express = require("express");
require("dotenv").config();
const app = express();
app.use(express.json());
// const { createTunnel } = require("./Helper/localtunnel");
const dateChanges = require("./Controllers/calculateDurationDays");
const overlapDateTimelines = require("./Controllers/overlapDateTimelines");
// const migrateAttachments = require("./SS_migrationControl/migration-service");
const attachmentRoutes = require("./Routes/attachment");
const migrateComments = require("./SS_ComentMig_Services/migration-comments");
const port = 8080 || process.env.PORT;

// const roschRouter = require("./Routes/roschRoutes");

// routes endpoint
//below endpoint cacluate days exclude weekend group by status
app.post(
  "/calculateCrossRowDateDiff_GroupBy",
  dateChanges.calculateCrossRowDateDiff_GroupBy
);
// below endpoint without grupy status label
app.post("/overlapDateTimelines", overlapDateTimelines.overlapDateTimelines);

// Endpoint for Smartshett data migrations to monday.com
app.use("/migrate", attachmentRoutes);

// endpoint for SS comments to monday.com >>>>
app.post("/migrate-comments", async (req, res) => {
  try {
    console.log("🚀 Received request to /migrate-comments");
    const result = await migrateComments(req.body);
    res.status(200).json(result);
  } catch (error) {
    console.error("❌ Migration failed:", error.message);
    res.status(500).json({
      success: false,
      error: "Comment migration failed",
      message: error.message,
    });
  }
});

app.listen(port, () => {
  console.log("started listening on port 8080");
  // createTunnel(port);
});
