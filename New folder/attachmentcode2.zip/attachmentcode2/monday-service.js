const initMondayClient = require("monday-sdk-js");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// handle complexity budget error if any
const executeWithRetry = async (fn, maxRetries = 5) => {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      const isBudgetError = err?.response?.data?.errors?.some(
        (e) =>
          e.message?.includes("Complexity budget") ||
          e.extensions?.code === "ComplexityBudgetExhausted"
      );

      if (isBudgetError) {
        const wait = 10 + attempt * 5;
        console.warn(
          `⚠️ Complexity budget exhausted. Waiting ${wait}s before retrying...`
        );
        await sleep(wait * 1000);
        continue;
      }

      throw err;
    }
  }

  throw new Error(
    "❌ Failed after multiple retries due to complexity budget limits."
  );
};

// get all board data with paginated
const getAllBoardItemsPaginated = async (token, boardId) => {
  const mondayClient = initMondayClient();
  mondayClient.setToken(token);
  mondayClient.setApiVersion("2023-10");

  let allItems = [];
  let cursor = null;

  do {
    const query = `query ($cursor: String) {
      boards (ids: [${boardId}]) {
        items_page (limit: 500, cursor: $cursor) {
          cursor
          items {
            id
            name
            column_values {
              id
              value
              text
            }
          }
        }
      }
    }`;

    const variables = { cursor };

    const response = await executeWithRetry(() =>
      mondayClient.api(query, { variables })
    );

    const page = response.data.boards[0].items_page;
    allItems.push(...page.items);
    cursor = page.cursor;
  } while (cursor);

  return { data: { items: allItems } };
};

// change column value for debug logs for each item
const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
  const mondayClient = initMondayClient({ token });
  const query = `mutation {
    change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value: """${value.replace(
    /"/g,
    '"'
  )}""") {
      id
    }
  }`;

  const response = await executeWithRetry(() => mondayClient.api(query));

  return response;
};

const addUpdateToItem = async (token, itemId, message) => {
  const mondayClient = initMondayClient();
  mondayClient.setToken(token);
  mondayClient.setApiVersion("2023-10");

  const escapedMessage = message.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

  const query = `mutation {
    create_update (item_id: ${itemId}, body: "${escapedMessage}") {
      id
    }
  }`;

  const response = await executeWithRetry(() => mondayClient.api(query));
  return response;
};

module.exports = {
  getAllBoardItemsPaginated,
  changeColumnValue,
  executeWithRetry,
  addUpdateToItem,
};

// const initMondayClient = require("monday-sdk-js");

// const getAllBoardItemsPaginated = async (token, boardId) => {
//   const mondayClient = initMondayClient();
//   mondayClient.setToken(token);
//   mondayClient.setApiVersion("2023-10");

//   let allItems = [];
//   let cursor = null;

//   do {
//     const query = `query ($cursor: String) {
//       boards (ids: [${boardId}]) {
//         items_page (limit: 500, cursor: $cursor) {
//           cursor
//           items {
//             id
//             name
//             column_values {
//               id
//               value
//               text
//             }
//           }
//         }
//       }
//     }`;

//     const variables = { cursor };
//     const response = await mondayClient.api(query, { variables });
//     const page = response.data.boards[0].items_page;
//     allItems.push(...page.items);
//     cursor = page.cursor;
//   } while (cursor);

//   return { data: { items: allItems } };
// };

// const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
//   const mondayClient = initMondayClient({ token });
//   const query = `mutation {
//     change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value: """${value.replace(
//     /"/g,
//     '"'
//   )}""") {
//       id
//     }
//   }`;
//   const response = await mondayClient.api(query);
//   return response;
// };

// module.exports = {
//   getAllBoardItemsPaginated,
//   changeColumnValue,
// };

// // const initMondayClient = require("monday-sdk-js");

// // const getBoardsAllData = async (token, boardId) => {
// //   return new Promise(async (resolve, reject) => {
// //     try {
// //       // const mondayClient = initMondayClient();
// //       // mondayClient.setToken(token);
// //       // mondayClient.setApiVersion("2023-10");
// //       // const query = `query  ($cursor: String) {
// //       //   boards (ids: [${boardId}]) {
// //       //     items_page(limit: 500, cursor: $cursor) {
// //       //       items {
// //       //         id
// //       //         name
// //       //         column_values {
// //       //           id
// //       //           value
// //       //           text
// //       //         }
// //       //       }
// //       //     }
// //       //   }
// //       // }`;
// //       // const response = await mondayClient.api(query);
// //       // resolve(response);

// //       const mondayClient = initMondayClient();
// //       mondayClient.setToken(token);
// //       mondayClient.setApiVersion("2023-10");

// //       let allItems = [];
// //       let cursor = null;

// //       do {
// //         const query = `query ($cursor: String) {
// //       boards (ids: [${boardId}]) {
// //         items_page (limit: 500, cursor: $cursor) {
// //           cursor
// //           items {
// //             id
// //             name
// //             column_values {
// //               id
// //               value
// //               text
// //             }
// //           }
// //         }
// //       }
// //     }`;

// //         const variables = { cursor };
// //         const response = await mondayClient.api(query, { variables });
// //         const page = response.data.boards[0].items_page;
// //         allItems.push(...page.items);
// //         cursor = page.cursor;
// //       } while (cursor);

// //       return { data: { items: allItems } };
// //     } catch (err) {
// //       reject(err);
// //     }
// //   });
// // };

// // const changeColumnValue = async (token, boardId, itemId, columnId, value) => {
// //   const mondayClient = initMondayClient({ token });
// //   const query = `mutation {
// //     change_simple_column_value(item_id: ${itemId}, board_id: ${boardId}, column_id: "${columnId}", value: """${value.replace(
// //     /"/g,
// //     '"'
// //   )}""") {
// //       id
// //     }
// //   }`;
// //   const response = await mondayClient.api(query);
// //   return response;
// // };

// // module.exports = {
// //   getBoardsAllData,
// //   changeColumnValue,
// // };
