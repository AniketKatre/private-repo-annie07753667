const fs = require("fs");
const path = require("path");
const {
  getAllBoardItemsPaginated,
  changeColumnValue,
  addUpdateToItem,
} = require("./monday-service");

const {
  getDiscussions,
  formatCommentWithReplies,
} = require("./smartsheet-service");

const migrateComments = async (payload) => {
  const {
    mondayToken = process.env.MONDAY_TOKEN,
    mondayBoardId,
    smartsheetToken,
    smartsheetSheetId,
    matchColumnId,
    matchColumnType = "name",
    updateColumnId, // text column in monday for logs
  } = payload;

  const progressPath = path.join(
    __dirname,
    "SSMigrationComm/progress",
    `migration-progress-${mondayBoardId}-${smartsheetSheetId}.json`
  );
  if (!fs.existsSync(path.dirname(progressPath))) {
    fs.mkdirSync(path.dirname(progressPath), { recursive: true });
  }

  let progress = {};
  if (fs.existsSync(progressPath)) {
    progress = JSON.parse(fs.readFileSync(progressPath));
  }

  const mondayItems = (
    await getAllBoardItemsPaginated(mondayToken, mondayBoardId)
  ).data.items;

  console.log(`📄 Loaded ${mondayItems.length} monday items`);

  // Fetch rows from Smartsheet
  const sheetUrl = `https://api.smartsheet.com/2.0/sheets/${smartsheetSheetId}`;
  const sheet = (
    await require("axios").get(sheetUrl, {
      headers: { Authorization: `Bearer ${smartsheetToken}` },
    })
  ).data;
  const columnIdMatch = sheet.columns.find(
    (c) => c.id == matchColumnId || c.title === matchColumnId
  )?.id;

  if (!columnIdMatch) {
    throw new Error(
      `❌ Match column not found in Smartsheet: ${matchColumnId}`
    );
  }

  const smartRows = sheet.rows;
  let migrated = 0;
  let skipped = 0;
  let totalComments = 0;

  for (let row of smartRows) {
    const cellValue = (
      row.cells.find((c) => c.columnId === columnIdMatch)?.displayValue || ""
    ).trim();

    if (!cellValue) continue;
    console.log(`🔍 Matching Smartsheet row "${cellValue}"`);

    for (let item of mondayItems) {
      const itemName = item.name?.trim();
      const columnsInfo = item.column_values
        ?.map((c) => `${c.id}: ${c.text}`)
        .join(", ");
      //   console.log(`📝 Checking Monday item "${itemName}" with columns `);
    }

    const mondayItem = mondayItems.find((item) => {
      const itemNameMatch = item.name?.trim() === cellValue;
      const columnMatch = item.column_values?.some(
        (c) => c.id === matchColumnType && c.text?.trim() === cellValue
      );
      return matchColumnType === "name" ? itemNameMatch : columnMatch;
    });

    if (!mondayItem) {
      console.log(`🔍 No monday item matched for "${cellValue}"`);
      continue;
    }

    const itemId = mondayItem.id;
    if (progress[itemId]) {
      console.log(`⏭️ Already processed item ${itemId}`);
      skipped++;
      continue;
    }

    const discussions = await getDiscussions(
      smartsheetSheetId,
      row.id,
      smartsheetToken
    );
    if (!discussions.length) {
      console.log(`🟡 No discussions for item ${itemId}`);
      progress[itemId] = { skipped: true };
      continue;
    }

    let logs = [];
    for (let d of discussions) {
      const commentBlock = formatCommentWithReplies(d);
      console.log("COMMMMENT:", commentBlock);
      try {
        await addUpdateToItem(mondayToken, itemId, commentBlock);
        logs.push(`✅ Uploaded comment ID: ${d.id}`);
        migrated++;
        totalComments++;
      } catch (err) {
        logs.push(`❌ Failed to upload comment ID: ${d.commentId}`);
      }
    }

    if (updateColumnId) {
      const value = `${logs.length}/${discussions.length} comments migrated from Smartsheet`;
      await changeColumnValue(
        mondayToken,
        mondayBoardId,
        itemId,
        updateColumnId,
        value
      );
    }

    progress[itemId] = { comments: discussions.map((c) => c.commentId), logs };
    fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2));
  }

  console.log(
    `✅ Migration complete. Total: ${smartRows.length}, Migrated: ${migrated}, Skipped: ${skipped}`
  );

  return {
    success: true,
    message: "✅ Comment migration completed.",
    migrated,
    skipped,
    totalComments,
  };
};

module.exports = migrateComments;
